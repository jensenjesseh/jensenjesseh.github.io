function brickCollide() {
    for(let col = 0; col<cols; col++){
        for(let row = 0; row<rows; row++){
            var toTest = blocks[row][col];
            if(toTest.alive === true){
                if((x+radius/2) > toTest.x && (x+radius/2) < toTest.x + 75 && (y-radius/2) > toTest.y && (y-radius/2) < toTest.y+20){
                    dy = -dy;
                    toTest.alive = false;
                }
            }
        }
    }
}

function wallCollide() {
        if((x+radius/2) > width || (x-radius/2) < 0){
               dx = -dx;
           } 
        if((y+radius/2) > height || (y-radius/2) < 0){
               dy = -dy;
           }
}

function paddleCollide(spec) {
    if((x+radius/2) > spec.x && (x+radius/2) < spec.x + 130 && (y+radius/2) > spec.y && (y-radius/2) < spec.y+15){
        dy = -dy;
        dx = 2*((x - (spec.x+65))/ (spec.width/2));
    }
}

function keyDown(pressed){
    if(pressed.keyCode==39){
		right=true;
		}
	else if(pressed.keyCode==37){
		left=true;
		}
}

function keyUp(lifted){
    if(lifted.keyCode==39){
		right=false;
		}
	else if(lifted.keyCode==37){
		left=false;
		}
}