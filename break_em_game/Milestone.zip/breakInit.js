var blocks =[];
var ball;
var cols = 14;
var rows = 8;
var dx = 2;
var dy = -2;
var radius = 5;
let inputStage = {};
var lifted;
var left = false;
var right = false;
var x = 0;
var y = 0;
var paddle;
var width;
var height;

function createBlocks(){
    var layer;
    for ( let i = 0; i < rows; i++){
        blocks.push([]);
        for(let j = 0; j < cols; j++){
            if(i === 7 || i === 6){
                layer = 'yellow';
            }

            else if(i === 5 || i === 4){
                layer = 'orange';
            }

            else if(i === 3 || i === 2){
                layer = 'blue';
            }

             else if(i === 1 || i === 0){
                layer = 'green';
            }

            blocks[i].push({x:j, y:i, color:layer, alive:true, init:false})
        }
    }
}

function initialize(){
    var canvas = document.getElementById('canvas-main');
        context = canvas.getContext('2d');

    x = canvas.width/2;
    y = canvas.height - 30;
    paddle = {x:x - 65, y:y + 1, width:130, height:15};
    width = canvas.width;
    height = canvas.height;

    createBlocks();

    CanvasRenderingContext2D.prototype.clear = function() {
        this.save();
        this.setTransform(1, 0, 0, 1, 0, 0);
        this.clearRect(0, 0, canvas.width, canvas.height);
        this.restore();
    };

    window.addEventListener("keydown", keyDown, false);
    window.addEventListener("keyup", keyUp, false);
    requestAnimationFrame(gameLoop);
}