var cancelRequest = false;
var timeLast = null;


var cancelRequest = false;
var timeLast = null;
function gameLoop() {
    var timeNow = performance.now();
    var duration = (timeNow - timeLast);

    collectInput(duration);

    update (duration);

    render();

    if(!cancelRequest) {
        requestAnimationFrame(gameLoop);
    }
};

function update(duration){
    x = x + dx;
    y = y + dy;
    brickCollide();
    wallCollide();
    paddleCollide(paddle);
}



function render() {
    graphics.clear();
    /*context.strokeStyle = '#191970';
    context.lineWidth = 2;
*/
    for(let row = 0;  row < rows ; row++){
        for(let col = 0; col < cols; col++) {
            graphics.drawBricks(blocks[row][col]);
        }
    }
   //context.stroke();
   graphics.drawBall();
   graphics.drawPaddle(paddle);

}



function collectInput(duration) {
    

}



function run() {

    cancelRequest = false;
    requestAnimationFrame(gameLoop);
}