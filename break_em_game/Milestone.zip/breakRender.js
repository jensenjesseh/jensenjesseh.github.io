var graphics = (function() {
    //'use strict';

    function clear() {
        context.clear();
    }


    function drawPaddle(spec) {
        if(spec.x > 0 && left){
            spec.x -= 7;
        }
        if(spec.x + spec.width < width && right){
            spec.x += 7;
        }
        context.beginPath();
        context.rect(spec.x, spec.y, spec.width, spec.height);
        context.fillStyle = 'rgb(16, 197, 229)';
        context.fill();
        context.closePath();
    }

    function drawBricks(spec) {
       
       
        if(spec.alive === true) {
            if(spec.init === false){
                 var xpos = (spec.x*(75 + 10) + 30);
                 var ypos = (spec.y*(20 + 10) + 30);
                 spec.x = xpos;
                 spec.y = ypos;
                 spec.init = true;
            }
            else{
                var xpos = spec.x;
                var ypos = spec.y;
            }

        context.beginPath();
        context.rect(xpos, ypos, 75, 20);
         if(spec.color === 'yellow'){
             context.fillStyle = 'rgb(255, 255, 102)';
         }

         else if(spec.color === 'orange'){
            context.fillStyle = 'rgb(255, 153, 51)';
         }

         else if(spec.color === 'blue'){
             context.fillStyle = 'rgb(102, 153, 255)';
         }

         else if(spec.color === 'green'){
             context.fillStyle = 'rgb(153, 255, 153)';
         }

         context.fill()
         context.closePath();
         context.lineWidth = 2;
         context.strokeStyle = '#191970';
         context.stroke();
        }
    }

    function drawBall() {
        context.beginPath();
        context.arc(x, y, radius, 0, Math.PI*2);
        context.fillStyle = '#ADD8E6';
        context.fill();
        context.closePath();

    }

    function Text(spec) {
        var that = {};

        that.updateRotation = function(angle) {
            spec.rotation += angle;
        };

    function measureTextHeight(spec) {
        context.save();

        context.font = spec.font;
        context.fillStyle = spec.fill;
        context.strokeStyle = spec.stroke;

        var height = context.measureText('m').width;

        context.restore();

        return height;
    }

    function measureTextWidth(spec) {
        context.save();

        context.font = spec.font;
        context.fillStyle = spec.fill;
        context.strokeStyle = spec.stroke;

        var width = context.measureText(spec.text).width;

        context.restore();

        return width;
    }

    that.draw = function() {
        context.save();

        context.font = spec.font;
        context.fillStyle = spec.fill;
        context.strokeStyle = spec.stroke;
        context.textBaseline = 'top';

        context.translate(spec.pos.x + that.width/2, spec.pos.y + that.height/2);
        context.rotate(spec.rotation);
        context.translate(-(spec.pos.x + that.width/2), -(spec.pos.y + that.height/2));

        context.fillText(spec.text, spec.pos.x, spec.pos.y);
        context.strokeText(spec.text, spec.pos.x, spec.pos.y);

        context.restore();
    };

    that.height = measureTextHeight(spec);
    that.width = measuretextWidth(spec);
    that.pos = spec.pos;

    return that;
    }

    return {
        clear : clear,
        drawBricks : drawBricks,
        drawBall : drawBall,
        drawPaddle : drawPaddle,
        Text : Text
    };

}());